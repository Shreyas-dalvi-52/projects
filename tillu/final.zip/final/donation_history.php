

<!DOCTYPE html>
<html>
<head>
	<title>LIFE SAVIOUR</title>
	<style>
		div.image{
      width:85%;
      overflow: auto;
      height:570px;
     margin-left: 15%;
      float: right;
    
			}
				table{
					margin-top: 100px;
			}
 				th{
                background-color:  #ee343f;
                color:white;
               }
             td{
                width: 120px;
               }
            tr{
                background-color: #FFB6C1;
                height: 30px;
            }
div.title{
      background-color: #ee343f;
      width:100%;
      height:50px;
      text-align: left;
      position: fixed;
    }
    .slogan{
      background-color: grey;
      position: relative;
      width: 85%;
      height:86px;
      float: right;
    }
    div.slogan p{
      margin-top: 35px;
    }
    *{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  list-style: none;
  text-decoration: none;
  font-family: 'Josefin Sans', sans-serif;
}

body{
   background-color: #f3f5f9;
}

.wrapper{
  width: 15%;
  height:885px;
   float:left;
   position: fixed;
   margin-top: 50px;
}

.wrapper .sidebar{
  width: 100%;
  height: 100%;
  background:   #343a40;
  padding: 30px 0px;
  float: left;
}


.wrapper .sidebar ul li{
  padding: 15px;
  border-bottom: 1px solid #bdb8d7;
  border-bottom: 1px solid rgba(0,0,0,0.05);
  border-top: 1px solid rgba(255,255,255,0.05);
}    

.wrapper .sidebar ul li a{
  color: #bdb8d7;
  display: block;
}


.wrapper .sidebar ul li:hover{
  background-color: #594f8d;
}
    
.wrapper .sidebar ul li:hover a{
  color: #fff;
}


	</style>
    <script>
        function link(){
        var path = window.location.pathname;
var page = path.split("/").pop();
console.log( page );
var page1=page.split(".").shift();
console.log( page1 );
document.getElementById(page1).style.color="#ee343f";
}
    </script>
</head>
<body onload="link()">
	<form method="post">
		<div class="title">
        	<span style="margin-top: 10px;"><font size="6" style="color:white">LIFE SAVIOUR</font></span>
        		<p align="right" style="float:right; margin-top:15px"><a style="color:white;" href="admin_logout.php">&nbsp;<font size="4">Logout</font>&nbsp;&nbsp;&nbsp;&nbsp;</a>	
        		
			</div>
		

<div class="wrapper">
    <div class="sidebar">
        
        <ul>
        	<li><a style="text-decoration:none;" id="donor_dash" href="donor_dash.php">Home</a></li>
            <li><a style="text-decoration:none;" href="donor_profile1.php?name=<?php echo $A;?>">Profile</a></li>
            <li><a style="text-decoration:none;" href="userRegister.php">Donate blood</a></li>
            <li><a style="text-decoration:none;" id="donation_history"href="donation_history.php">Donation History</a></li>
        </ul> 
	</div>
</div>
	<div class="image">
		<center><table style="border: 1px solid black;" >
            <th >NAME</th>
        
            <th>BLOOD GRP</th>
            <th>MOB_NO</th>
            <th>DATE</th>
           
            <?php
            session_start();
            $name=$_SESSION['username'];
                $conn= mysqli_connect("localhost", "root", "", "LS");
                $q= "select * from DONATE_BLOOD where DONATION_STATUS='COMPLETED' AND NAME='$name'";
                $res= mysqli_query($conn, $q);
                while( $row= mysqli_fetch_assoc($res) ) //associative array
                {
                ?>
                    <tr>
                        <td><?php echo $row['NAME']?></td>   <!-- for printing a element in table -->
                        <td><?php echo $row['BLOOD_GROUP']?></td>
                        <td><?php echo $row['MOB_NO']?></td>
                        <td><?php echo $row['DATE']?></td> 
                    </tr>
                
            <?php 
                } 
            ?>
        
        </table>
        </center>
	</div>
	<br><br><br><br>
		<div class="slogan">
    <p style="color:white; font-family: Verdana; text-align: center;">
		Donate blood and be the reason for someone's existence</p>
	</div>
	</form>
</body>
</html>
