<!DOCTYPE html>
<html>
<head>
	<title>Certificate</title>
	<style type="text/css">
		body{
			
			background-image: url("https://i.pinimg.com/564x/b4/35/96/b435961299a2f2f23ead45742ca985e0.jpg");
			background-repeat: no-repeat;			
			background-position: center;
			background-attachment: fixed; 
			background-size:contain;
			
		}
		h1{
			margin:0px 0px 50px 630px;
			color: darkred;
			font-size: 60px;
			
		}
		
		img{
			position:absolute;
			margin-left: 960px;
			top:90px;
			height: 120px;
			width: 120px;
		    
			
		   }
		
		h2{color:navy;
			font-size:30px;
            font-family: Cambria;
			margin-left: 480px;
			
		}
		
		
		h3{
			margin:30px 0px 50px 0px;
			color: Gold;
			font-family:Monotype Corsiva;
			font-size: 40px;
			
		
		}
		p{   
			margin: 20px 0px 30px 480px;
			color: navy;
			font-family: monotype corsiva;
			font-weight: bold;
			font-size: 27px;
			line-height: 33px;
		}
		.box{
			margin-left: 375px;
			display: flex;
			flex-direction: row;
			height: 100px;
			width: 765px;
		}
		.b1{
			flex:2.5;
		}
		.b2{
			flex:50.5;
		}
		.sign{
			margin-left: 400px;
			margin-top: 450px;
			height: 100px;
			width: 130px;
		}
		
	</style>
</head>
<body>
	<div>
          <h1>Life Saviour </h1>
		
	     <h2>Celebrate Your Birthday<br>by donating Blood... </h2>
		 <img src=" https://media.istockphoto.com/id/1329175330/vector/blood-donors-logo-template-design-vector-emblem-design-concept-creative-symbol-icon.jpg?s=612x612&w=0&k=20&c=MQ7wi0sPodHAuAzUJBRf82vEEAuTWkTLWyqttXvH0fg=">
		  
		<center>
		 <h3>Certificate of Donation</h3>
		</center>
		
	    <p>This certificate has been awarded to Mr./Mrs./Miss<br>_____________________________________<br> for his/her valantry Blood Donation to our blood centre<br>on_____________________________________<br>Blood Group_____________________<br>you contribution to the noble cause is highly appreciate </p>
		
		<img src="https://png.pngitem.com/pimgs/s/518-5182834_blue-signature-hd-png-download.png" class="sign">
		<div class="box">
			<div class="b1">
				
			</div>
			<div class="b2">
			         
				    <h4 style="color: navy; font-size: 20px; margin:  90px 0px 0px;"> Authorized Signature</h4>
					<h4 style="color: navy; font-size: 20px; margin: 0px 0px 0px 0px;">Head Of,Life Saviour</h4>
					<h4 style="color: navy; font-size: 20px; margin: 0px 0px 0px 0px;">Ahmednagar-414001</h4>
				
			</div>
			
		</div>
	</div>
</body>
</html>